import { readFile, access } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const require = createRequire(import.meta.url), C = require('../dist/core.js');
for (const name of ['index.html', 'app.js', 'core.js', 'stream-check.js', 'style.css', 'osd.css', 'vendor/hls.min.js', 'manifest.webmanifest']) await access(join(root, 'dist', name));
const channels = JSON.parse(await readFile(join(root, 'dist/channels.json'), 'utf8'));
if (!channels.length || channels.some(c => !C.isAllowedChannel(c) || c.health?.status !== 'reachable')) throw new Error('The seed catalogue must contain checked allowed channels only');
if (C.dedupeChannels(channels).length !== channels.length) throw new Error('Duplicate seed stations found');
if (new Set(channels.map(c => c.id)).size !== channels.length || new Set(channels.map(c => c.number)).size !== channels.length) throw new Error('Duplicate channel IDs or numbers found');
console.log(`Ready: ${channels.length} unique seed channels; static app in dist/.`);
console.log('Historical reachability is not a guarantee of current stream availability.');
