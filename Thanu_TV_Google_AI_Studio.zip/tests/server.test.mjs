import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { createRequire } from 'node:module';
import { createAppServer } from '../server.mjs';
const expectedChannels = createRequire(import.meta.url)('../dist/channels.json');

test('the portable server serves the real app, seed channels and assets without exposing project files', async () => {
  const server = createAppServer();
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const origin = `http://127.0.0.1:${server.address().port}`;
  try {
    const page = await fetch(origin + '/');
    assert.equal(page.status, 200); assert.match(page.headers.get('content-type'), /text\/html/);
    assert.match(await page.text(), /id="channelDrawer"/);
    const list = await fetch(origin + '/channels.json');
    const channels = await list.json(); assert.deepEqual(channels, expectedChannels);
    const js = await fetch(origin + '/core.js'); assert.match(js.headers.get('content-type'), /javascript/);
    const manifest = await fetch(origin + '/manifest.webmanifest'); assert.match(manifest.headers.get('content-type'), /manifest\+json/);
    assert.equal((await fetch(origin + '/vendor/hls.min.js', { method: 'HEAD' })).status, 200);
    assert.equal((await fetch(origin + '/healthz')).status, 200);
    for (const url of ['/missing.js', '/package.json', '/server.mjs', '/.env', '/%2e%2e%2fpackage.json']) assert.ok([403,404].includes((await fetch(origin + url)).status), url);
    assert.equal((await fetch(origin + '/', { method: 'POST' })).status, 405);
  } finally { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
});
