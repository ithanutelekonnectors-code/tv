const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const C=require('../dist/core.js');
const original=JSON.parse(fs.readFileSync(require('node:path').join(__dirname,'../dist/channels.json'),'utf8'));

test('the checked catalogue survives export and reimport without lost names or URLs',()=>{
  const parsed=C.parseM3U(C.exportM3U(original));
  assert.equal(parsed.channels.length,original.length);assert.equal(parsed.rejected,0);
  assert.deepEqual(parsed.channels.map(c=>[c.name,c.url,c.group]),original.map(c=>[c.name,c.url,c.group]));
});
test('M3U parser handles BOM, commas in attributes and names, EXTGRP and URL-only text',()=>{
  const result=C.parseM3U('\uFEFF#EXTM3U\r\n#EXTINF:-1 group-title="Tamil, News" tvg-name="fallback" tvg-logo="javascript:alert(1)",தமிழ், TV\r\nhttps://example.com/tamil/live.m3u8\r\n#EXTINF:-1,Second\r\n#EXTGRP:Music\r\nhttps://example.com/music/live.m3u8\r\nhttps://example.com/third/index.m3u8');
  assert.equal(result.channels.length,3);assert.equal(result.channels[0].name,'தமிழ், TV');assert.equal(result.channels[0].group,'Tamil, News');assert.equal(result.channels[0].logo,'');assert.equal(result.channels[1].group,'Music');assert.equal(result.channels[2].name,'third');
});
test('unsafe URLs and duplicate links cannot pollute imports or exports',()=>{
  const parsed=C.parseM3U('#EXTINF:-1,Bad\njavascript:alert(1)\n#EXTINF:-1,Good\nhttps://example.com/live.m3u8\n#EXTINF:-1,Duplicate\nhttps://example.com/live.m3u8\nfile:///etc/passwd');
  assert.equal(parsed.channels.length,1);assert.equal(parsed.rejected,2);assert.equal(parsed.duplicates,1);
  const merged=C.mergeChannels(parsed.channels,[...parsed.channels,{...parsed.channels[0],name:'Another channel',url:'https://example.com/other.m3u8'}]);assert.equal(merged.added,1);assert.equal(merged.duplicates,1);assert.notEqual(merged.channels[0].id,merged.channels[1].id);
});
test('channel navigation wraps inside the chosen list and recovers from a hidden current selection',()=>{
  const list=original.slice(0,3);assert.equal(C.nextChannel(list,list[2].id,1).id,list[0].id);assert.equal(C.nextChannel(list,list[0].id,-1).id,list[2].id);assert.equal(C.nextChannel(list,'not-in-list',1).id,list[0].id);assert.equal(C.nextChannel([],null,1),null);
});
test('Tamil search, group/category filters, favourite sets and recent order compose correctly',()=>{
  const a={id:'a',number:1,name:'தமிழ் செய்திகள்',language:'ta',group:'News'},b={id:'b',number:2,name:'Isai TV',language:'ta',group:'Music'},c={id:'c',number:3,name:'English News',language:'en',group:'News'};
  assert.deepEqual(C.filterChannels([a,b,c],{query:'தமிழ்',category:'Tamil'}).map(c=>c.id),['a']);assert.deepEqual(C.filterChannels([a,b,c],{view:'favourites',favourites:['a','b'],category:'Music'}).map(c=>c.id),['b']);assert.deepEqual(C.filterChannels([a,b,c],{view:'recent',recent:['c','a'],group:'News'}).map(c=>c.id),['c','a']);assert.deepEqual(C.filterChannels([a,b,c],{query:'english news'}).map(c=>c.id),['c']);
});
test('remote mappings include channel keys, Android fallback, D-pad, back, numbers and custom keys',()=>{
  assert.equal(C.remoteAction({key:'ChannelUp',keyCode:0}),'next');assert.equal(C.remoteAction({key:'Unidentified',keyCode:167}),'previous');assert.equal(C.remoteAction({key:'ArrowLeft',keyCode:37}),'left');assert.equal(C.remoteAction({key:'Unidentified',keyCode:23}),'select');assert.equal(C.remoteAction({key:'BrowserBack',keyCode:166}),'back');assert.equal(C.remoteAction({key:'Unidentified',keyCode:461}),'back');assert.equal(C.remoteAction({key:'4',keyCode:52}),'number:4');assert.equal(C.remoteAction({key:'F9'},{next:'key:F9'}),'next');assert.equal(C.remoteAction({key:'Unidentified',keyCode:999},{previous:'code:999'}),'previous');
});

test('Christian metadata and confirmed brand variants are removed without matching unrelated channel names',()=>{
  for(const c of [{name:'Anything',group:'Christian Devotional'},{name:'MADHA TV (576p)'},{name:'JeevaOli TV'},{name:'Nijam TV GalaxyOTT'},{name:'Blood Off Jesus Tv'},{name:'இயேசு டிவி'},{name:'IBC Siluvai'},{name:'Blessing TV Tamil'},{name:'Grace TV Madurai'},{name:'Chutti Grace TV'},{name:'Village TV (1080p)',group:'Religious'},{name:'Family tv',url:'https://jctvapp.lanevservices.in/jcfcapp/jctvlive/playlist.m3u8'}])assert.equal(C.isChristianChannel(c),true,c.name);
  for(const name of ['Shark TV','MS Mathan TV','Tamilan TV Zion Chunks','Deiveega Oli TV','Sathiyam TV','Polimer News'])assert.equal(C.isChristianChannel({name,group:'TAMIL'}),false,name);
  const rows=[{id:'ok',name:'News',url:'https://example.com/news.m3u8'},{id:'religion',name:'Madha TV',url:'https://example.com/religion.m3u8'},{id:'failed',name:'Old stream',url:'https://example.com/old.m3u8',health:{status:'failed'}}];assert.deepEqual(C.filterChannels(rows,{}).map(c=>c.id),['ok']);assert.ok(!C.exportM3U(rows).includes('/religion.'));assert.ok(!C.exportM3U(rows).includes('/old.'));
});

test('import numbering cannot collide with hidden or restored original channel numbers',()=>{
  const original=[{id:'a',number:7,url:'https://example.com/a.m3u8'},{id:'b',number:400,url:'https://example.com/b.m3u8'}];
  const merged=C.mergeChannels(original,[{id:'new',number:3,url:'https://example.com/new.m3u8'}],{minimumNumber:789});assert.equal(merged.channels.at(-1).number,789);assert.equal(new Set(merged.channels.map(c=>c.number)).size,3);
  const migrated=C.mergeChannels([{...original[0],legacyIds:['former'],legacyNumbers:[900]}],[{id:'former',url:'https://example.com/new.m3u8'}]);assert.equal(migrated.channels[1].number,901);assert.notEqual(migrated.channels[1].id,'former');
});

test('station variants collapse across stream URLs and preserve previous names, IDs and tuning numbers',()=>{
  const a={id:'a',number:7,name:'Example TV HD',language:'ta',region:'Madurai',url:'https://one.example/live.m3u8'};
  const b={id:'b',number:12,name:'Example Channel',language:'tamil',region:'Madurai',url:'https://two.example/live.m3u8'};
  const c={id:'c',number:19,name:'Example TV [1Cloud]',region:'Madurai',url:'https://three.example/live.m3u8'};
  const result=C.dedupeChannels([a,b,c]);assert.equal(result.length,1);assert.equal(result[0].id,'a');assert.equal(result[0].url,a.url);assert.deepEqual(result[0].legacyIds,['b','c']);assert.deepEqual(result[0].legacyNumbers,[12,19]);
  assert.equal(C.filterChannels(result,{query:'19'}).length,1);assert.equal(C.filterChannels(result,{query:'Example Channel'}).length,1);
  assert.equal(C.createChannelMatcher(result)({...b,url:'https://four.example/live.m3u8'}).id,'a');assert.equal(C.parseM3U(C.exportM3U([a,b,c])).channels.length,1);
});

test('different regions, explicit languages and distinct sister channels remain separately selectable',()=>{
  const rows=[['City TV','ta','Chennai'],['City TV HD','ta','Madurai'],['City TV','en','Chennai'],['Thanthi TV','ta',''],['Thanthi One','ta',''],['Polimer TV','ta',''],['Polimer News','ta','']].map(([name,language,region],i)=>({id:String(i),number:i+1,name,language,region,url:'https://example.com/'+i+'.m3u8'}));
  assert.equal(C.dedupeChannels(rows).length,rows.length);for(const row of rows)assert.equal(C.createChannelMatcher(rows)(row).id,row.id);
  const parsed=C.parseM3U('#EXTINF:-1 tvg-region="Madurai" tvg-country="IN",City TV\nhttps://example.com/a.m3u8');assert.equal(parsed.channels[0].region,'Madurai');assert.equal(parsed.channels[0].country,'IN');
});

test('a Christian label cannot be lost behind a duplicate generic URL, in either file order',()=>{
  const generic='#EXTINF:-1,General TV\nhttps://example.com:443/live.m3u8#one\n',blocked='#EXTINF:-1 group-title="Christian",Specific TV\nhttps://example.com/live.m3u8#two\n';
  for(const text of [generic+blocked,blocked+generic]){const parsed=C.parseM3U(text);assert.equal(parsed.channels.length,1);assert.equal(parsed.duplicates,1);assert.equal(C.isAllowedChannel(parsed.channels[0]),false);}
});

test('known source aliases merge without stripping arbitrary regional station names',()=>{
  for(const [a,b] of [['EET TV','EET TV Canada'],['Sooriyan TV','Sooriyan TV Canada'],['Dharsan TV','Dharshan TV SD']])assert.equal(C.sameChannel({name:a,url:'https://one.example/live.m3u8'},{name:b,url:'https://two.example/live.m3u8'}),true,a);
  assert.equal(C.sameChannel({name:'Suriyan TV',url:'https://one.example/live.m3u8'},{name:'Suriyan TV Karur',url:'https://two.example/live.m3u8'}),false);
  assert.equal(C.sameChannel({name:'News 7 Tamil',language:'ta',url:'https://one.example/live.m3u8'},{name:'News 7 Tamil',url:'https://two.example/live.m3u8'}),true);
  assert.equal(C.sameChannel({name:'Eye Tamil',language:'ta',url:'https://one.example/live.m3u8'},{name:'Eye Tamil TV',url:'https://two.example/live.m3u8'}),true);
});
