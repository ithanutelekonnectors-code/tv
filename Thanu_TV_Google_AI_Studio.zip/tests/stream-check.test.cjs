const test=require('node:test'),assert=require('node:assert/strict');
require('../dist/core.js');const {checkChannel,checkBatch}=require('../dist/stream-check.js');
const channel={id:'x',name:'Local News',url:'https://example.com/master.m3u8'};
function response(url,text,bytes=512){return{url,ok:true,status:200,type:'cors',text:async()=>text,arrayBuffer:async()=>new Uint8Array(bytes).fill(71).buffer};}
test('a stream is checked only after its media playlist and actual segment bytes respond',async()=>{
  const calls=[];const fetchImpl=async url=>{calls.push(url);if(url.endsWith('master.m3u8'))return response(url,'#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=500000\nlow/live.m3u8');if(url.endsWith('.m3u8'))return response(url,'#EXTM3U\n#EXT-X-MAP:URI="init.mp4"\n#EXTINF:5,\nseg.m4s');return response(url,'');};
  const result=await checkChannel(channel,{fetchImpl});assert.equal(result.ok,true);assert.deepEqual(calls,['https://example.com/master.m3u8','https://example.com/low/live.m3u8','https://example.com/low/init.mp4','https://example.com/low/seg.m4s']);assert.ok(result.checkedAt);
});
test('a valid manifest with an unreachable segment stays excluded',async()=>{
  const result=await checkChannel(channel,{fetchImpl:async url=>url.endsWith('.m3u8')?response(url,'#EXTM3U\n#EXTINF:5,\nmissing.ts'):{url,ok:false,status:404}});assert.equal(result.ok,false);assert.equal(result.reason,'http_404');
});
test('Christian, HTTP and unsupported inputs are excluded before making any network request',async()=>{
  let calls=0;for(const c of [{...channel,name:'Nambikkai TV'},{...channel,url:'http://example.com/live.m3u8'},{...channel,url:'https://example.com/live.mpd'}])assert.equal((await checkChannel(c,{fetchImpl:async()=>{calls++;}})).ok,false);assert.equal(calls,0);
});
test('timeout aborts a stuck check without labelling the stream permanently offline',async()=>{
  const fetchImpl=async(_,options)=>new Promise((resolve,reject)=>options.signal.addEventListener('abort',()=>reject(Object.assign(new Error('aborted'),{name:'AbortError'}))));
  const result=await checkChannel(channel,{fetchImpl,timeoutMs:15});assert.equal(result.ok,false);assert.equal(result.reason,'check_timed_out');
});
test('batch checking preserves input order and reports completion with bounded concurrency',async()=>{
  let active=0,max=0,completed=0;const fetchImpl=async url=>{active++;max=Math.max(max,active);await new Promise(r=>setTimeout(r,2));active--;return response(url,url.endsWith('.m3u8')?'#EXTM3U\n#EXTINF:5,\nseg.ts':'');};const results=await checkBatch(Array.from({length:5},(_,i)=>({...channel,id:String(i)})),{fetchImpl,concurrency:2,onProgress:done=>{completed=done;}});assert.deepEqual(results.map(r=>r.channel.id),['0','1','2','3','4']);assert.ok(results.every(r=>r.ok));assert.ok(max<=2);assert.equal(completed,5);
});
