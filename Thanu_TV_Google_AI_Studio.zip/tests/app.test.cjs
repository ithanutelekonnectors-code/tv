const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {JSDOM,VirtualConsole}=require('jsdom');
const base=path.join(__dirname,'../dist');
const catalog=JSON.parse(fs.readFileSync(path.join(base,'channels.json'),'utf8'));
const polimer=catalog.find(c=>c.name==='Polimer News');
const pause=ms=>new Promise(r=>setTimeout(r,ms));

async function harness(saved,fullscreenMode='supported',options={}){
  const errors=[],virtualConsole=new VirtualConsole();virtualConsole.on('jsdomError',e=>errors.push(e));
  const dom=new JSDOM(fs.readFileSync(path.join(base,'index.html'),'utf8'),{url:'https://thanu-tv.example/',runScripts:'outside-only',pretendToBeVisual:true,virtualConsole});
  const w=dom.window,d=w.document,video=d.getElementById('video');
  const rejectUrls=new Set(options.rejectUrls||[]);
  w.AbortController=AbortController;w.TextDecoder=TextDecoder;
  w.fetch=async(url)=>{
    if(url==='channels.json')return{ok:true,json:async()=>structuredClone(options.catalog||catalog)};
    const ok=!rejectUrls.has(url),body=String(url).endsWith('.ts')?new Uint8Array(512).fill(71):null;
    return{ok,status:ok?200:404,url:String(url),type:'cors',text:async()=>'#EXTM3U\n#EXT-X-TARGETDURATION:5\n#EXTINF:5,\nsegment.ts\n',arrayBuffer:async()=>body?.buffer||new Uint8Array(512).fill(71).buffer};
  };
  w.HTMLElement.prototype.scrollIntoView=function(){};w.scrollTo=()=>{};
  w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','');};w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open');};
  let paused=true,playCalls=0,blockPlay=false;
  Object.defineProperty(video,'paused',{get:()=>paused});Object.defineProperty(video,'readyState',{get:()=>2});Object.defineProperty(video,'duration',{get:()=>Infinity});
  video.load=()=>{};video.play=()=>{playCalls++;if(blockPlay)return Promise.reject(Object.assign(new Error('User gesture needed'),{name:'NotAllowedError'}));paused=false;video.dispatchEvent(new w.Event('playing'));return Promise.resolve();};
  video.pause=()=>{if(paused)return;paused=true;video.dispatchEvent(new w.Event('pause'));};
  video.canPlayType=()=>'';
  let fullscreen=null,fullscreenCalls=0,fullscreenExits=0;const fullscreenSnapshots=[];
  Object.defineProperty(d,'fullscreenElement',{get:()=>fullscreen,configurable:true});
  if(fullscreenMode!=='unavailable')d.getElementById('videoStage').requestFullscreen=function(){fullscreenCalls++;fullscreenSnapshots.push({playCalls,hlsCount:hlsInstances.length});if(fullscreenMode==='blocked')return Promise.reject(new Error('Fullscreen blocked'));fullscreen=this;d.dispatchEvent(new w.Event('fullscreenchange'));return Promise.resolve();};
  d.exitFullscreen=()=>{fullscreenExits++;fullscreen=null;d.dispatchEvent(new w.Event('fullscreenchange'));return Promise.resolve();};
  const mediaActions={};w.MediaMetadata=class {constructor(data){Object.assign(this,data);}};
  Object.defineProperty(w.navigator,'mediaSession',{value:{playbackState:'none',setActionHandler:(action,fn)=>{mediaActions[action]=fn;}},configurable:true});
  const hlsInstances=[];
  class FakeHls{
    static isSupported(){return true;}
    static Events={MEDIA_ATTACHED:'attached',MANIFEST_PARSED:'parsed',ERROR:'error'};
    static ErrorTypes={MEDIA_ERROR:'mediaError',NETWORK_ERROR:'networkError'};
    constructor(){this.handlers={};this.levels=[{height:360},{height:720}];hlsInstances.push(this);}
    on(event,handler){this.handlers[event]=handler;}
    attachMedia(v){this.video=v;queueMicrotask(()=>{if(!this.destroyed)this.handlers.attached?.();});}
    loadSource(url){this.url=url;queueMicrotask(()=>{if(!this.destroyed)this.handlers.parsed?.();});}
    destroy(){this.destroyed=true;}
    recoverMediaError(){this.recoveries=(this.recoveries||0)+1;}
    fatal(code=403){this.handlers.error?.('error',{fatal:true,type:'networkError',response:{code}});}
  }
  w.Hls=FakeHls;w.Blob=Blob;
  const blobs=[];w.URL.createObjectURL=blob=>{blobs.push(blob);return'blob:test';};w.URL.revokeObjectURL=()=>{};
  w.HTMLAnchorElement.prototype.click=function(){/* Capture Blob without triggering jsdom navigation. */};
  if(saved)w.localStorage.setItem('thanu-tv-v1',saved);
  w.eval(fs.readFileSync(path.join(base,'core.js'),'utf8'));w.eval(fs.readFileSync(path.join(base,'stream-check.js'),'utf8'));w.eval(fs.readFileSync(path.join(base,'app.js'),'utf8'));await pause(25);
  return{dom,w,d,video,errors,hlsInstances,blobs,mediaActions,rejectUrls,fullscreenSnapshots,fullscreenCalls:()=>fullscreenCalls,fullscreenExits:()=>fullscreenExits,playCalls:()=>playCalls,blockPlayback:v=>blockPlay=v,click:id=>d.getElementById(id).click(),key:(key,keyCode=0)=>d.dispatchEvent(new w.KeyboardEvent('keydown',{key,keyCode,bubbles:true,cancelable:true})),saved:()=>w.localStorage.getItem('thanu-tv-v1')};
}

test('browse, Tamil/name search, category focus, favourites and device persistence work together',async()=>{
  const h=await harness();try{
    assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length));assert.equal(h.d.querySelectorAll('.channel-card').length,40);assert.equal(h.playCalls(),0);
    const search=h.d.getElementById('search');search.value='Polimer';search.dispatchEvent(new h.w.Event('input'));assert.ok(h.d.querySelectorAll('.channel-card').length>0);assert.ok([...h.d.querySelectorAll('.channel-info h3')].every(n=>/polimer/i.test(n.textContent)));
    h.click('clearFilters');const music=[...h.d.querySelectorAll('.category-tab')].find(b=>b.textContent==='Music');music.click();assert.equal(h.d.activeElement.textContent,'Music');assert.ok(h.d.querySelectorAll('.channel-card').length>0);
    h.click('clearFilters');h.click('saveCurrent');assert.equal(h.d.getElementById('favCount').textContent,'1');h.d.querySelector('[data-view="favourites"]').click();assert.equal(h.d.querySelectorAll('.channel-card').length,1);
    const state=h.saved();const h2=await harness(state);try{assert.equal(h2.d.getElementById('favCount').textContent,'1');assert.equal(h2.d.getElementById('saveCurrent').getAttribute('aria-pressed'),'true');assert.equal(h2.playCalls(),0);}finally{h2.dom.window.close();}
    assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('real UI drives HLS lifecycle, channel +/- and numeric tuning, without claiming playback before playing',async()=>{
  const h=await harness();try{
    assert.equal(h.d.getElementById('stageStatus').textContent,'READY TO WATCH');h.click('watchButton');await pause(10);assert.equal(h.d.getElementById('stageStatus').textContent,'PLAYING');assert.equal(h.d.getElementById('quality').options.length,3);
    const first=JSON.parse(h.saved()).last;h.click('nextChannel');await pause(10);assert.notEqual(JSON.parse(h.saved()).last,first);assert.equal(h.hlsInstances[0].destroyed,true);
    h.key('PageDown',34);await pause(10);assert.equal(JSON.parse(h.saved()).last,first);
    for(const n of String(polimer.number))h.key(n);h.key('Enter',13);await pause(10);assert.equal(JSON.parse(h.saved()).last,polimer.id);assert.equal(h.d.getElementById('nowName').textContent,'Polimer News');
    h.key(' ');assert.equal(h.video.paused,true);h.key(' ');await pause(10);assert.equal(h.video.paused,false);
    h.d.querySelector('[data-view="recent"]').click();assert.ok(h.d.querySelectorAll('.channel-card').length>=2);assert.equal(h.d.querySelector('.channel-card').dataset.id,polimer.id);assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('failed streams disappear, automatically advance, persist as hidden, and stale engine errors cannot hide the new channel',async()=>{
  const h=await harness();try{
    assert.ok(catalog.every(c=>c.url.startsWith('https:')));h.click('watchButton');await pause(10);const old=h.hlsInstances.at(-1);h.click('nextChannel');await pause(10);old.fatal(403);assert.equal(h.d.getElementById('playerError').hidden,true);
    const failed=JSON.parse(h.saved()).last;h.click('saveCurrent');h.hlsInstances.at(-1).fatal(403);assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length-1));assert.equal(h.d.querySelector('[data-channel="'+failed+'"]'),null);assert.equal(h.d.getElementById('favCount').textContent,'0');await pause(210);assert.equal(h.d.getElementById('stageStatus').textContent,'PLAYING');assert.notEqual(JSON.parse(h.saved()).last,failed);
    h.click('channelsButton');assert.equal(h.d.querySelector('[data-osd-channel="'+failed+'"]'),null);h.key('BrowserBack',166);
    const h2=await harness(h.saved());try{assert.equal(h2.d.getElementById('totalCount').textContent,String(catalog.length-1));assert.equal(h2.d.querySelector('[data-channel="'+failed+'"]'),null);}finally{h2.dom.window.close();}assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('imports merge, duplicate URLs are skipped, titles remain text, and M3U export contains the selected collection',async()=>{
  const h=await harness();try{
    const text='#EXTM3U\n#EXTINF:-1 group-title="New",<img src=x onerror=alert(1)>\nhttps://example.com/new/master.m3u8\n#EXTINF:-1,Duplicate\n'+catalog[0].url+'\n';
    const input=h.d.getElementById('fileInput');Object.defineProperty(input,'files',{value:[{name:'test.m3u',size:text.length,text:async()=>text}],configurable:true});input.dispatchEvent(new h.w.Event('change'));await pause(20);
    assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length+1));assert.match(h.d.getElementById('toast').textContent,/1 channels added · 1 duplicate/);
    const search=h.d.getElementById('search');search.value='<img';search.dispatchEvent(new h.w.Event('input'));assert.equal(h.d.querySelectorAll('.channel-card').length,1);assert.equal(h.d.querySelector('.channel-info h3').textContent,'<img src=x onerror=alert(1)>');assert.equal(h.d.querySelector('.channel-info h3 img'),null);
    h.click('downloadButton');const exported=await h.blobs.at(-1).text();assert.ok(exported.includes('https://example.com/new/master.m3u8'));assert.ok(!exported.includes(catalog[0].url));
    h.click('settingsButton');h.click('resetPlaylist');assert.equal(h.d.getElementById('restoreConfirm').hidden,false);h.click('confirmRestore');assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length));assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('background preference, remote key learning, and unavailable PiP give usable controls',async()=>{
  const h=await harness();try{
    h.click('settingsButton');assert.equal(h.d.getElementById('settingsDialog').open,true);h.click('settingsBackground');assert.equal(JSON.parse(h.saved()).background,false);assert.equal(h.d.getElementById('backgroundToggle').getAttribute('aria-checked'),'false');
    h.d.querySelector('[data-learn="next"]').click();h.key('F9',120);assert.equal(JSON.parse(h.saved()).remote.next,'key:F9');h.key('Escape',27);assert.equal(h.d.getElementById('settingsDialog').open,false);
    const original=JSON.parse(h.saved()).last;h.key('F9',120);await pause(10);assert.notEqual(JSON.parse(h.saved()).last,original);
    h.click('settingsButton');assert.equal(h.d.getElementById('settingsPip').disabled,true);assert.match(h.d.getElementById('pipSupport').textContent,/unavailable/);assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('autoplay refusal returns a visible play button and never reports a false live state',async()=>{
  const h=await harness();try{
    h.blockPlayback(true);h.click('watchButton');await pause(10);assert.equal(h.d.getElementById('stageStatus').textContent,'PRESS PLAY');assert.equal(h.d.getElementById('playerPlaceholder').hidden,false);assert.equal(h.d.getElementById('loadingOverlay').hidden,true);
    h.blockPlayback(false);h.click('watchButton');await pause(10);assert.equal(h.d.getElementById('stageStatus').textContent,'PLAYING');assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('visibility policy continues background playback or pauses and resumes, and system media controls change channels',async()=>{
  const h=await harness();try{
    let hidden=false;Object.defineProperty(h.d,'hidden',{get:()=>hidden,configurable:true});
    h.click('watchButton');await pause(10);assert.equal(h.w.navigator.mediaSession.playbackState,'playing');assert.equal(h.w.navigator.mediaSession.metadata.title,h.d.getElementById('nowName').textContent);
    hidden=true;h.d.dispatchEvent(new h.w.Event('visibilitychange'));assert.equal(h.video.paused,false);
    hidden=false;h.d.dispatchEvent(new h.w.Event('visibilitychange'));h.click('backgroundToggle');hidden=true;h.d.dispatchEvent(new h.w.Event('visibilitychange'));assert.equal(h.video.paused,true);
    hidden=false;h.d.dispatchEvent(new h.w.Event('visibilitychange'));await pause(10);assert.equal(h.video.paused,false);
    const first=JSON.parse(h.saved()).last;h.mediaActions.nexttrack();await pause(10);assert.notEqual(JSON.parse(h.saved()).last,first);h.mediaActions.previoustrack();await pause(10);assert.equal(JSON.parse(h.saved()).last,first);h.mediaActions.pause();assert.equal(h.video.paused,true);h.mediaActions.stop();assert.equal(h.d.getElementById('nowLabel').textContent,'PLAYBACK STOPPED');assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('D-pad moves focus between real controls and remote Back exits search editing',async()=>{
  const h=await harness();try{
    const bounds={previousChannel:{left:100,top:100,width:50,height:35},nextChannel:{left:170,top:100,width:50,height:35},saveCurrent:{left:30,top:100,width:50,height:35}};
    for(const[id,rect]of Object.entries(bounds)){const b=h.d.getElementById(id);b.getClientRects=()=>[rect];b.getBoundingClientRect=()=>rect;}
    h.d.getElementById('previousChannel').focus();h.key('ArrowRight',39);assert.equal(h.d.activeElement.id,'nextChannel');h.key('ArrowLeft',37);assert.equal(h.d.activeElement.id,'previousChannel');
    h.d.getElementById('search').focus();h.key('BrowserBack',166);assert.equal(h.d.activeElement.id,'videoStage');assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('selecting a channel immediately enters fullscreen, and remote OK opens the left drawer without pausing',async()=>{
  const h=await harness();try{
    assert.equal(h.fullscreenCalls(),0);h.d.querySelector('[data-channel="'+catalog[0].id+'"]').click();
    assert.equal(h.fullscreenCalls(),1);assert.deepEqual(h.fullscreenSnapshots[0],{playCalls:0,hlsCount:0});await pause(10);
    assert.equal(h.d.fullscreenElement.id,'videoStage');assert.equal(h.d.activeElement.id,'videoStage');assert.equal(h.video.paused,false);
    const engine=h.hlsInstances.at(-1),plays=h.playCalls();h.key('Enter',13);
    assert.equal(h.d.getElementById('drawerOverlay').hidden,false);assert.equal(h.d.querySelectorAll('[data-osd-channel]').length,catalog.length);assert.equal(h.d.activeElement.dataset.osdChannel,catalog[0].id);assert.equal(h.video.paused,false);assert.equal(h.playCalls(),plays);assert.notEqual(engine.destroyed,true);
    h.key('ArrowDown',40);assert.equal(h.d.activeElement.dataset.osdChannel,catalog[1].id);h.key('Select',23);await pause(10);
    assert.equal(h.d.getElementById('drawerOverlay').hidden,true);assert.equal(JSON.parse(h.saved()).last,catalog[1].id);assert.equal(h.d.fullscreenElement.id,'videoStage');assert.equal(h.fullscreenCalls(),1);assert.equal(h.video.paused,false);assert.equal(h.d.activeElement.id,'videoStage');assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('Back closes the drawer before exiting fullscreen and leaves video playback running',async()=>{
  const h=await harness();try{
    h.click('watchButton');await pause(10);h.key('Unidentified',23);assert.equal(h.d.getElementById('drawerOverlay').hidden,false);
    const current=JSON.parse(h.saved()).last;h.key('BrowserBack',166);assert.equal(h.d.getElementById('drawerOverlay').hidden,true);assert.equal(h.d.fullscreenElement.id,'videoStage');assert.equal(h.fullscreenExits(),0);assert.equal(h.d.activeElement.id,'videoStage');
    h.key('BrowserBack',166);await pause(5);assert.equal(h.d.fullscreenElement,null);assert.equal(h.fullscreenExits(),1);assert.equal(h.video.paused,false);assert.equal(JSON.parse(h.saved()).last,current);assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('drawer search, saved-channel filter, D-pad selection and Tab focus stay inside the overlay',async()=>{
  const h=await harness();try{
    h.click('saveCurrent');h.click('watchButton');await pause(10);h.click('channelsButton');h.click('drawerFavourites');assert.equal(h.d.querySelectorAll('[data-osd-channel]').length,1);
    h.click('drawerAll');const search=h.d.getElementById('drawerSearch');search.focus();search.value='Polimer';search.dispatchEvent(new h.w.Event('input'));
    assert.ok(h.d.querySelectorAll('[data-osd-channel]').length>0);assert.ok([...h.d.querySelectorAll('.drawer-channel-info strong')].every(e=>/polimer/i.test(e.textContent)));
    h.key(' ');assert.equal(h.video.paused,false);h.key('ArrowDown',40);const selected=h.d.activeElement.dataset.osdChannel;assert.ok(selected);
    h.key('Enter',13);await pause(10);assert.equal(JSON.parse(h.saved()).last,selected);assert.equal(h.d.getElementById('drawerOverlay').hidden,true);
    h.key('Enter',13);h.d.getElementById('closeDrawer').focus();h.d.dispatchEvent(new h.w.KeyboardEvent('keydown',{key:'Tab',shiftKey:true,bubbles:true,cancelable:true}));assert.ok(h.d.getElementById('channelDrawer').contains(h.d.activeElement));
    h.d.getElementById('drawerSearch').value='not-a-real-channel-abc';h.d.getElementById('drawerSearch').dispatchEvent(new h.w.Event('input'));assert.equal(h.d.getElementById('drawerEmpty').hidden,false);h.key('ArrowDown',40);assert.equal(h.d.activeElement.id,'drawerSearch');h.key('BrowserBack',166);assert.equal(h.d.getElementById('drawerOverlay').hidden,true);assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('fullscreen refusal or a missing API uses a full-window player with the channel drawer still available',async()=>{
  for(const mode of ['blocked','unavailable']){
    const h=await harness(undefined,mode);try{
      h.click('watchButton');await pause(10);assert.equal(h.video.paused,false);assert.equal(h.d.getElementById('videoStage').classList.contains('full-window'),true);assert.equal(h.d.body.classList.contains('full-window-open'),true);
      h.key('Enter',13);assert.equal(h.d.getElementById('drawerOverlay').hidden,false);h.key('BrowserBack',166);assert.equal(h.d.getElementById('videoStage').classList.contains('full-window'),true);
      h.key('BrowserBack',166);assert.equal(h.d.getElementById('videoStage').classList.contains('full-window'),false);assert.equal(h.d.body.classList.contains('full-window-open'),false);assert.equal(h.video.paused,false);assert.deepEqual(h.errors,[]);
    }finally{h.dom.window.close();}
  }
});

test('held OK does not open and immediately select a channel, and number tuning confirms from an open drawer',async()=>{
  const h=await harness();try{
    h.click('watchButton');await pause(10);h.key('Enter',13);const current=JSON.parse(h.saved()).last;
    h.d.dispatchEvent(new h.w.KeyboardEvent('keydown',{key:'Enter',keyCode:13,repeat:true,bubbles:true,cancelable:true}));assert.equal(h.d.getElementById('drawerOverlay').hidden,false);assert.equal(JSON.parse(h.saved()).last,current);
    for(const n of String(polimer.number))h.key(n);h.key('Enter',13);await pause(10);assert.equal(JSON.parse(h.saved()).last,polimer.id);assert.equal(h.d.getElementById('drawerOverlay').hidden,true);assert.equal(h.fullscreenCalls(),1);assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('Christian and unconfirmed channels cannot return through saved imports, favourites, the OSD or exports',async()=>{
  const christian={id:'excluded',number:999,name:'Madha TV',url:'https://example.com/madha.m3u8',group:'TAMIL',health:{status:'reachable',checkedAt:new Date().toISOString()}},unconfirmed={id:'unconfirmed',number:998,name:'Old import',url:'https://example.com/old.m3u8'};
  const saved=JSON.stringify({imports:[christian,unconfirmed],favourites:['excluded',catalog[0].id],last:'excluded'});
  const h=await harness(saved,'supported',{catalog:[...catalog,christian,unconfirmed]});try{
    assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length));assert.equal(h.d.getElementById('favCount').textContent,'1');assert.notEqual(JSON.parse(h.saved()).last,'excluded');h.click('channelsButton');assert.equal(h.d.querySelector('[data-osd-channel="excluded"]'),null);assert.equal(h.d.querySelector('[data-osd-channel="unconfirmed"]'),null);h.key('BrowserBack',166);h.click('downloadButton');const text=await h.blobs.at(-1).text();assert.ok(!text.includes('madha.m3u8'));assert.ok(!text.includes('old.m3u8'));assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('imports reject Christian, HTTP and failed streams while keeping a checked new channel',async()=>{
  const h=await harness(undefined,'supported',{rejectUrls:['https://example.com/fails.m3u8']});try{
    const text='#EXTM3U\n#EXTINF:-1,Madha TV\nhttps://example.com/madha.m3u8\n#EXTINF:-1,Insecure\nhttp://example.com/http.m3u8\n#EXTINF:-1,Failed\nhttps://example.com/fails.m3u8\n#EXTINF:-1,New channel\nhttps://example.com/good.m3u8\n';
    const input=h.d.getElementById('fileInput');Object.defineProperty(input,'files',{value:[{name:'filtered.m3u',size:text.length,text:async()=>text}],configurable:true});input.dispatchEvent(new h.w.Event('change'));await pause(30);
    assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length+1));assert.match(h.d.getElementById('verificationStatus').textContent,/1 checked channels added · 3 excluded/);const imports=JSON.parse(h.saved()).imports;assert.equal(imports.length,1);assert.equal(imports[0].name,'New channel');assert.equal(imports[0].health.status,'reachable');assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('an offline device keeps its channels and a hidden failed stream returns only after a successful recheck',async()=>{
  const h=await harness();try{
    let online=false;Object.defineProperty(h.w.navigator,'onLine',{get:()=>online,configurable:true});h.click('watchButton');await pause(10);h.hlsInstances.at(-1).fatal(503);assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length));assert.match(h.d.getElementById('errorTitle').textContent,/Internet connection/);
    online=true;h.click('retryButton');await pause(10);const failed=JSON.parse(h.saved()).last,failedChannel=catalog.find(c=>c.id===failed);h.hlsInstances.at(-1).fatal(404);await pause(210);assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length-1));
    h.rejectUrls.add(failedChannel.url);h.click('settingsButton');h.click('recheckHidden');await pause(20);assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length-1));h.rejectUrls.delete(failedChannel.url);h.click('recheckHidden');await pause(20);assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length));assert.equal(JSON.parse(h.saved()).hiddenChannels.length,0);h.key('Escape');for(const n of String(failedChannel.number))h.key(n);h.key('Enter');await pause(10);assert.equal(JSON.parse(h.saved()).last,failedChannel.id);assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('an ended live feed is removed and a fully hidden collection offers a recheck instead of a stale channel',async()=>{
  const h=await harness();try{
    h.click('watchButton');await pause(10);const current=JSON.parse(h.saved()).last;h.video.dispatchEvent(new h.w.Event('ended'));assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length-1));await pause(210);assert.notEqual(JSON.parse(h.saved()).last,current);assert.equal(h.video.paused,false);
  }finally{h.dom.window.close();}
  const row=catalog[0],saved=JSON.stringify({last:row.id,hiddenChannels:[{channel:row,reason:'failed'}]});const h2=await harness(saved,'supported',{catalog:[row]});try{
    assert.equal(h2.d.getElementById('totalCount').textContent,'0');assert.equal(h2.d.getElementById('watchButton').disabled,true);assert.match(h2.d.getElementById('heroChannel').textContent,/No checked/);h2.click('settingsButton');h2.click('recheckHidden');await pause(20);assert.equal(h2.d.getElementById('totalCount').textContent,'1');assert.equal(h2.d.getElementById('watchButton').disabled,false);assert.deepEqual(h2.errors,[]);
  }finally{h2.dom.window.close();}
});

test('merged station IDs preserve saved favourites, recent history and old numeric remote tuning',async()=>{
  const row={...catalog[0],id:'primary',number:3,name:'Migration TV HD',legacyIds:['former'],legacyNumbers:[52]};
  const imported={...row,id:'old-import',number:600,name:'Migration TV SD',url:'https://example.com/migration.m3u8',legacyIds:[],legacyNumbers:[]};
  const saved=JSON.stringify({imports:[imported],favourites:['former','old-import'],recent:['former','old-import'],last:'former'});
  const h=await harness(saved,'supported',{catalog:[row]});try{
    assert.equal(h.d.getElementById('totalCount').textContent,'1');assert.equal(h.d.getElementById('favCount').textContent,'1');assert.equal(JSON.parse(h.saved()).last,'primary');assert.deepEqual(JSON.parse(h.saved()).recent,['primary']);
    for(const n of '52')h.key(n);h.key('Enter');await pause(10);assert.equal(JSON.parse(h.saved()).last,'primary');assert.equal(h.video.paused,false);
    h.click('channelsButton');assert.equal(h.d.querySelectorAll('[data-osd-channel]').length,1);h.key('BrowserBack');h.click('downloadButton');assert.equal((await h.blobs.at(-1).text()).split('#EXTINF:').length-1,1);assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('multi-file imports exclude blocked aliases and failed feeds while combining newly checked station variants',async()=>{
  const h=await harness(undefined,'supported',{rejectUrls:['https://example.com/fails.m3u8']});try{
    const texts=['#EXTINF:-1,Added TV HD\nhttps://example.com/fails.m3u8\n#EXTINF:-1,Added TV SD\nhttps://example.com/good.m3u8\n#EXTINF:-1,Added Channel\nhttps://example.com/second.m3u8\n#EXTINF:-1,Generic TV\nhttps://example.com/blocked.m3u8\n#EXTINF:-1,'+catalog[0].name+'\nhttps://example.com/existing-variant.m3u8\n','#EXTINF:-1 group-title="Christian",Another name\nhttps://example.com/blocked.m3u8\n'];
    const input=h.d.getElementById('fileInput');Object.defineProperty(input,'files',{value:texts.map((text,i)=>({name:i+'.m3u',size:text.length,text:async()=>text})),configurable:true});input.dispatchEvent(new h.w.Event('change'));await pause(30);
    assert.equal(h.d.getElementById('totalCount').textContent,String(catalog.length+1));assert.match(h.d.getElementById('toast').textContent,/1 channels added · 2 duplicates skipped/);assert.match(h.d.getElementById('verificationStatus').textContent,/1 checked channels added · 3 excluded/);
    const imports=JSON.parse(h.saved()).imports;assert.equal(imports.length,1);assert.equal(imports[0].url,'https://example.com/good.m3u8');h.click('downloadButton');const exported=await h.blobs.at(-1).text();assert.ok(!exported.includes('blocked.m3u8'));assert.ok(!exported.includes('fails.m3u8'));assert.ok(!exported.includes('second.m3u8'));assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});

test('rechecking an older hidden variant cannot recreate a duplicate card or renumber the checked station',async()=>{
  const row={...catalog[0],id:'primary',number:3,name:'Recheck TV HD'},old={...row,id:'older',number:52,name:'Recheck TV SD',url:'https://example.com/older.m3u8'};
  const h=await harness(JSON.stringify({hiddenChannels:[{channel:old,reason:'failed'}]}),'supported',{catalog:[row]});try{
    h.click('settingsButton');h.click('recheckHidden');await pause(20);assert.equal(h.d.getElementById('totalCount').textContent,'1');assert.equal(JSON.parse(h.saved()).hiddenChannels.length,0);h.key('Escape');for(const n of '52')h.key(n);h.key('Enter');await pause(10);assert.equal(JSON.parse(h.saved()).last,'primary');assert.match(h.d.getElementById('nowMeta').textContent,/003/);assert.deepEqual(h.errors,[]);
  }finally{h.dom.window.close();}
});
