# Thanu TV — Google AI Studio web app

Thanu TV-யின் தற்போதைய source code இந்த project-இல் உள்ளது. இதில் 368 தனித்துவமான seed சேனல்கள், video player, M3U import/export, favourites, search, Jio remote key mappings, இடதுபுற OSD பட்டியல் மற்றும் browser ஆதரிக்கும் background playback உள்ளன.

## Google AI Studio-வில் பயன்படுத்துதல்

1. `Thanu_TV_Google_AI_Studio.zip` கோப்பைப் பதிவிறக்கி extract செய்யுங்கள்.
2. உங்கள் GitHub-இல் ஒரு புதிய private repository உருவாக்கி, extract செய்த project files-ஐ upload செய்யுங்கள். `package.json`, `server.mjs`, `dist/`, `tests/` ஆகியவை repository-யின் root-இல் இருக்க வேண்டும். ZIP கோப்பை மட்டும் upload செய்ய வேண்டாம்; அதன் உள்ளே உள்ள files தேவை.
3. https://aistudio.google.com/apps திறந்து **Build** பகுதியில் prompt box-இன் **+ → Import from GitHub** வழியாக அந்த repository-ஐத் தேர்வு செய்யுங்கள். Platform தேர்வு இருந்தால் **Web** தேர்வு செய்யுங்கள்.
4. `AI_STUDIO_PROMPT.txt` உள்ள முழு prompt-ஐ paste செய்து இயக்குங்கள். AI Studio agent-ஐ project-ஐத் திறந்து preview-ஐ இயக்கச் சொல்லும் prompt இது.
5. Preview-இல் channel selection, remote OK drawer, CH +/−, search, favourites மற்றும் import-ஐச் சரிபார்க்குங்கள். Fullscreen அல்லது PiP preview iframe-இல் கட்டுப்படுத்தப்பட்டால் app-ஐ அதன் தனிப்பட்ட tab-இல் திறந்து சோதியுங்கள். Browser அனுமதிக்காத fullscreen-க்கு full-window fallback ஏற்கெனவே உள்ளது.

மேலே உள்ள படிகள் Google ஆவணங்களில் விளக்கப்பட்டுள்ள GitHub import முறையைப் பயன்படுத்துகின்றன.

Official reference (checked 2026-10-16):
https://ai.google.dev/gemini-api/docs/aistudio-build-mode

## Project இயக்குதல்

Node.js 20 அல்லது அதற்குப் பிந்தைய version தேவை. Player-ஐ இயக்க runtime npm dependencies அல்லது Gemini API key தேவையில்லை.

```bash
npm run dev
```

Default: `http://localhost:3000`. Server `0.0.0.0`-இல் listen செய்யும். `PORT` environment variable அல்லது `--port` argument மூலம் port-ஐ மாற்றலாம். Production command: `npm start`.

```bash
npm ci
npm run build
npm test
```

`npm ci` test dependency-ஐ நிறுவும். `npm run build` ஏற்கெனவே தயாராக உள்ள `dist/` source மற்றும் catalogue-ஐ validate செய்யும்; compilation தேவையில்லை. `npm test` player/import/remote tests மற்றும் portable HTTP server test-ஐ இயக்கும். Static hosting-க்கு `dist/` folder மட்டும் போதும்; Node hosting-க்கு முழு project மற்றும் `npm start` பயன்படுத்தலாம்.

## சேனல் வடிகட்டல்

- ஒரே URL, HD/SD/resolution மற்றும் அறியப்பட்ட provider/name variants ஒன்றாக இணைக்கப்படும்.
- வேறு மொழி அல்லது ஊர் metadata கொண்ட சேனல்கள் தனியாக இருக்கும்.
- Christian சேனல்கள் விலக்கப்படும்.
- புதிய imports-க்கு playlist மற்றும் media bytes சோதனை செய்யப்படும். வெற்றி பெற்றவை மட்டுமே சேரும்.
- Playback failure அல்லது live feed end ஏற்பட்டால் சேனல் சாதனத்தில் மறைக்கப்பட்டு அடுத்த சேனல் முயற்சிக்கப்படும். Settings → Recheck hidden streams மூலம் வெற்றி பெற்ற இணைப்புகளை மீட்டெடுக்கலாம்.

368 என்பது 2026-10-16 catalogue snapshot. Stream response, geography மற்றும் provider CORS விதிகள் காலத்துடனும் app origin-உடனும் மாறலாம். இந்த எண்ணிக்கை நிரந்தர uptime அல்லது video decoding உத்தரவாதம் அல்ல. சில streams புதிய Google preview/deployment origin-இல் இயங்காமல் இருக்கலாம்; அவற்றுக்கு filter-ஐத் தளர்த்த வேண்டாம்.

## Remote மற்றும் fullscreen

- Player focus-இல் OK / Enter: வீடியோவின் மேல் இடதுபுற சேனல் பட்டியல்.
- ↑/↓: பட்டியலில் நகர்தல். OK: தேர்வு, பட்டியல் மூடல், fullscreen.
- Back: முதலில் பட்டியலை மூடும்; அடுத்த Back fullscreen-இலிருந்து வெளியேறும்.
- CH +/−, PageUp/PageDown மற்றும் numeric tuning ஆதரவு உள்ளது.
- Settings-இல் remote key learning உள்ளது. TV system/browser தடுத்த keys app-க்கு வராது.
- Browser/OS அனுமதிக்கும் வரை background audio, Media Session மற்றும் PiP செயல்படும். இது native Android foreground service அல்ல.

## சேமித்த favourites

தரவு browser localStorage-இல் `thanu-tv-v1` என்ற key-இல் இருக்கும். புதிய Google domain-க்கு பழைய domain-இன் favourites/history தானாக நகராது. பழைய app-இல் Export favourites மூலம் பட்டியலை backup செய்யலாம்; புதிய app-இல் தேவையான சேனல்களை மீண்டும் favourite செய்யுங்கள்.

## Source மற்றும் சரிபார்ப்பு

Original app: https://thanu-tv.fabledcabin2.chatgpt.site/

இந்த export-இன் `dist/` files வெளியிடப்பட்ட source commit `10904e060cde0aae73f3b8bdd98e9a140d3a0994`-இலிருந்து எடுக்கப்பட்டவை. Hosting identity அல்லது deployment credentials இந்த project-இல் தேவையில்லை. `SOURCE_INFO.json` provenance-ஐக் கொண்டுள்ளது.

Original app-இன் 37 automated tests export-இல் உள்ளன; portable server-க்கு ஒரு கூடுதல் HTTP test உள்ளது. Export உருவாக்கும்போது 38 tests-ம் வெற்றி பெற்றன; build validation-ம் வெற்றி பெற்றது. Tests media/device APIs-ஐ simulate செய்கின்றன. Google AI Studio account-இல் import/preview மற்றும் நேரடி Jio hardware playback இங்கே சோதிக்கப்படவில்லை.

HLS.js-இன் MIT licence மற்றும் fonts-இன் OFL licences `dist/vendor/` மற்றும் `dist/fonts/`-இல் சேர்க்கப்பட்டுள்ளன.
